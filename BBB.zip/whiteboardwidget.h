#ifndef WHITEBOARDWIDGET_H
#define WHITEBOARDWIDGET_H

#include <QWidget>
#include <QTextEdit>
#include <QLineEdit>
#include <QPushButton>
#include <QVBoxLayout>
#include <QLabel>
#include <memory>
#include "user.h"

class WhiteboardWidget : public QWidget
{
    Q_OBJECT

public:
    explicit WhiteboardWidget(const QString& sessionTitle, std::shared_ptr<User> user, QWidget* parent = nullptr);

private slots:
    void handleSend();

private:
    std::shared_ptr<User> currentUser;
    QString title;
    QLabel* sessionLabel;
    QTextEdit* boardArea;
    QLineEdit* inputField;
    QPushButton* sendBtn;
};

#endif // WHITEBOARDWIDGET_H
