#include "admin.h"
#include "session.h"

Admin::Admin(int userID, QString name, QString lastname, const QString& password, Role level, QWidget* parent)
    : User(userID, name, lastname, password, level, parent),
    adminLevel(level),
    currentSession(nullptr) {}

Role Admin::getRole() const {
    return adminLevel;
}

bool Admin::createSession(const Session& /*session*/) {
    return adminLevel == Role::Admin || adminLevel == Role::SuperAdmin;
}

bool Admin::deleteSession(int /*sessionId*/) {
    return adminLevel == Role::Admin || adminLevel == Role::SuperAdmin;
}

bool Admin::manageUser(User& /*user*/, const QString& /*action*/) {
    return adminLevel == Role::SuperAdmin;
}

bool Admin::joinSession(Session* session) {
    if (session && (adminLevel == Role::Admin || adminLevel == Role::SuperAdmin)) {
        session->addParticipant(this);
        currentSession = session;
        return true;
    }
    return false;
}

bool Admin::leaveSession() {
    if (currentSession) {
        currentSession->removeParticipant(this);
        currentSession = nullptr;
        return true;
    }
    return false;
}
