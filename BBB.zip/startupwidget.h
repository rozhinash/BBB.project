#ifndef STARTUPWIDGET_H
#define STARTUPWIDGET_H

#include <QWidget>
#include <memory>
#include <QString>

#include "authmanager.h"
#include "loginwidget.h"

class StartupWidget : public QWidget
{
    Q_OBJECT

public:
    explicit StartupWidget(QWidget *parent = nullptr);
    void handleLogin(QString username, QString password);

private:
    std::shared_ptr<AuthManager> auth;
    LoginWidget* loginWidget;
};

#endif // STARTUPWIDGET_H
