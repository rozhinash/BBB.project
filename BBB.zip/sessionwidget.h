#ifndef SESSIONWIDGET_H
#define SESSIONWIDGET_H

#include <QWidget>
#include <QListWidget>
#include <QPushButton>
#include <QVBoxLayout>
#include <QLabel>
#include <memory>
#include "user.h"

class SessionWidget : public QWidget
{
    Q_OBJECT

public:
    explicit SessionWidget(std::shared_ptr<User> currentUser, QWidget* parent = nullptr);

private slots:
    void handleCreateSession();
    void handleEnterSession();

private:
    std::shared_ptr<User> user;
    QListWidget* sessionList;
    QPushButton* createBtn;
    QPushButton* enterBtn;
    QLabel* infoLabel;

    void loadSessions(); // خواندن جلسه‌ها از دیتابیس یا لیست مجازی
};

#endif // SESSIONWIDGET_H
