#include "logmanager.h"

logmanager::logmanager(const QString logFilePath) : m_logFile(logFilePath){
    m_logFile.open(QIODevice::Append | QIODevice::Text);
}
logmanager::~logmanager() {
    if (m_logFile.isOpen())
        m_logFile.close();
}

void logmanager::writeLog(const QString& level , const QString& message){
    if (!m_logFile.isOpen())
        return ;

    QTextStream out(&m_logFile);
    QString timestamp = QDateTime::currentDateTime().toString("yyy-MM-dd  HH:mm:ss");
    out << "[" << timestamp <<"] [" << level << "]" << message <<"\n";
    out.flush();
}

void logmanager::logInfo(const QString& message){
    writeLog("INFO" , message);
}

void logmanager::logWarning(const QString& message){
    writeLog("WARNING" , message);
}

void logmanager::logError(const QString& message){
    writeLog("ERROR" , message);
}

