#ifndef DATABASE_H
#define DATABASE_H

#include <memory>
#include<QString>
#include <QSqlDatabase>
#include "user.h"
class Database {
private:
   QSqlDatabase m_db;

public:
    Database();
    ~Database();

    bool openConnection();     //وصل شدن به دیتا بیس
    void closeConnection();   // قطع اتصال
    bool createUserTable();  // ایجاد جدول برای یوزر ها


    std::shared_ptr<User> getUser(const QString& name , const QString& lastname ) const;
    bool userExists(const QString& name , const QString& lastname) const;
    void addUser(const std::shared_ptr<User> & user);
};

#endif // DATABASE_H
