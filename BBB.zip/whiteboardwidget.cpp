#include "whiteboardwidget.h"

WhiteboardWidget::WhiteboardWidget(const QString& sessionTitle, std::shared_ptr<User> user, QWidget* parent)
    : QWidget(parent), currentUser(user), title(sessionTitle)
{
    sessionLabel = new QLabel("جلسه: " + title, this);
    boardArea = new QTextEdit(this);
    boardArea->setReadOnly(true);

    inputField = new QLineEdit(this);
    sendBtn = new QPushButton("ارسال", this);

    auto layout = new QVBoxLayout(this);
    layout->addWidget(sessionLabel);
    layout->addWidget(boardArea);
    layout->addWidget(inputField);
    layout->addWidget(sendBtn);

    connect(sendBtn, &QPushButton::clicked, this, &WhiteboardWidget::handleSend);
}

void WhiteboardWidget::handleSend()
{
    QString content = inputField->text().trimmed();
    if (!content.isEmpty()) {
        boardArea->append(currentUser->getName() + ": " + content);
        inputField->clear();
    }
}
