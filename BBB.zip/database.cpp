#include "database.h"
#include <QSqlQuery>
#include <QDebug>
#include <QSqlError>

Database::Database() {
    m_db = QSqlDatabase::addDatabase("QSQLITE");
    m_db.setDatabaseName("users.db");
}

Database::~Database() {
    closeConnection();
}

bool Database::openConnection() {
    if (!m_db.open()) {
        qDebug() << "اتصال برقرار نشد!";
        return false;
    }
    qDebug() << "اتصال برقرار شد!";
    return true;
}

void Database::closeConnection() {
    if (m_db.isOpen())
        m_db.close();
}

bool Database::createUserTable() {
    QSqlQuery query;
    QString command =
        "CREATE TABLE IF NOT EXISTS users ("
        "id INTEGER PRIMARY KEY AUTOINCREMENT, "
        "name TEXT NOT NULL, "
        "lastname TEXT NOT NULL, "
        "password TEXT NOT NULL, "
        "role INTEGER)";
    if (!query.exec(command)) {
        qDebug() << "جدول ساخته نشد ×!" << query.lastError();
        return false;
    }
    qDebug() << "جدول ساخته شد!";
    return true;
}

std::shared_ptr<User> Database::getUser(const QString& name, const QString& lastname) const {
    QSqlQuery query;
    query.prepare("SELECT password, role FROM users WHERE name = :name AND lastname = :lastname");
    query.bindValue(":name", name);
    query.bindValue(":lastname", lastname);

    if (query.exec() && query.next()) {
        QString password = query.value("password").toString();
        int roleValue = query.value("role").toInt();
        Role role = static_cast<Role>(roleValue);
        return std::make_shared<User>(0, name, lastname, password, role);
    }
    return nullptr;
}

bool Database::userExists(const QString& name, const QString& lastname) const {
    QSqlQuery query;
    query.prepare("SELECT COUNT(*) FROM users WHERE name = :name AND lastname = :lastname");
    query.bindValue(":name", name);
    query.bindValue(":lastname", lastname);

    return query.exec() && query.next() && query.value(0).toInt() > 0;
}

void Database::addUser(const std::shared_ptr<User>& user) {
    QSqlQuery query;
    query.prepare("INSERT INTO users (name, lastname, password, role) VALUES (:name, :lastname, :password, :role)");
    query.bindValue(":name", user->getName());
    query.bindValue(":lastname", user->getLastName());
    query.bindValue(":password", user->getPassword());
    query.bindValue(":role", static_cast<int>(user->getRole()));

    if (!query.exec())
        qDebug() << "خطا در افزودن کاربر:" << query.lastError();
}
