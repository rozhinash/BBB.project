#ifndef AUTHMANAGER_H
#define AUTHMANAGER_H

#include <memory>
#include <QString>
#include "database.h"
#include "logmanager.h"
#include "user.h"
#include "role.h"

class AuthManager {
public:
    AuthManager(std::shared_ptr<Database> db, std::shared_ptr<logmanager> logger);

    std::shared_ptr<User> login(const QString& name, const QString& lastname, const QString& password);
    std::shared_ptr<User> getLoggedInUser(const QString& username , const QString& password);
    bool registerUser(const QString& name, const QString& lastname, const QString& password, const QString& role);
    QString encryptPassword(const QString& plainPassword);
private:

    std::shared_ptr<Database> database;
    std::shared_ptr<logmanager> logManager;
};

#endif // AUTHMANAGER_H
