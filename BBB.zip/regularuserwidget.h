#ifndef REGULARUSERWIDGET_H
#define REGULARUSERWIDGET_H

#include <QWidget>
#include <memory>
#include "regularuser.h"

namespace Ui {
class RegularUserWidget;
}

class RegularUserWidget : public QFrame
{
    Q_OBJECT

public:
    explicit RegularUserWidget(std::shared_ptr<RegularUser> user, QWidget *parent = nullptr);
    ~RegularUserWidget();

private slots:
    void onViewHistoryClicked();
    void onJoinSessionClicked();
    void onLeaveSessionClicked();

private:
    Ui::RegularUserWidget *ui;
    std::shared_ptr<RegularUser> currentUser;
};

#endif // REGULARUSERWIDGET_H
