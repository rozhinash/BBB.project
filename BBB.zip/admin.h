#ifndef ADMIN_H
#define ADMIN_H

#include "../User/user.h"
#include "role.h"
#include "session.h"

class Session; // forward declaration

class Admin : public User {
private:
    Role adminLevel;
    Session* currentSession; // جلسه‌ای که ادمین در آن شرکت کرده

public:
    Admin(int userID, QString name, QString lastname, const QString& password, Role level, QWidget* parent = nullptr);

    Role getRole() const;

    bool createSession(const Session& session);
    bool deleteSession(int sessionId);
    bool manageUser(User& user, const QString& action);

    bool joinSession(Session* session);
    bool leaveSession();
};

#endif // ADMIN_H
