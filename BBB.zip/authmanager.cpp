#include "authmanager.h"
#include "database.h"
#include "logmanager.h"
#include <QDebug>

AuthManager::AuthManager(std::shared_ptr<Database> db, std::shared_ptr<logmanager> logger)
    : database(db), logManager(logger) {}

std::shared_ptr<User> AuthManager::login(const QString& name, const QString& lastname, const QString& password) {
    auto user = database->getUser(name, lastname);
    if (user && user->getPassword() == encryptPassword(password)) {
        logManager->writeLog("Info" , "ورود موفق برای:" +name+ " " + lastname);
        return user;
    }
    logManager->writeLog("Error" , "ورود ناموفق برای:" +name+ " " +lastname);
    return nullptr;
}

bool AuthManager::registerUser(const QString& name, const QString& lastname, const QString& password, const QString& roleStr) {
    if (database->userExists(name, lastname)) {
        logManager->writeLog("Warning" , "ثبت‌نام ناموفق: کاربر قبلاً وجود دارد" +name+ " " +lastname);
        return false;
    }

    Role role = (roleStr.toLower() == "admin") ? Role::Admin : Role::Regular;

    // چون کانستراکتور User شامل 6 آرگومان هست، باید parent هم بدیم یا مقدار پیش‌فرض تعریف شده باشه
    auto user = std::make_shared<User>(1, name, lastname, encryptPassword(password), role, nullptr);

    database->addUser(user);
    logManager->writeLog("Info" , "ثبت نام موفقیت امیز" +name+ " " +lastname);
    return true;
}

QString AuthManager::encryptPassword(const QString& plainPassword) {
    QString reversed;
    for (int i = plainPassword.size() - 1; i >= 0; --i)
        reversed.append(plainPassword[i]);
    return reversed;
}
