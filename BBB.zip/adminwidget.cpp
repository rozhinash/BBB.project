#include "adminwidget.h"
#include <QMessageBox>

AdminWidget::AdminWidget(QWidget *parent)
    : QWidget(parent)
{
    setupLayout();

    // اتصال سیگنال‌ها به اسلات‌ها
    connect(createSessionButton, &QPushButton::clicked, this, &AdminWidget::onCreateSessionClicked);
    connect(deleteSessionButton, &QPushButton::clicked, this, &AdminWidget::onDeleteSessionClicked);
    connect(joinSessionButton, &QPushButton::clicked, this, &AdminWidget::onJoinSessionClicked);
    connect(leaveSessionButton, &QPushButton::clicked, this, &AdminWidget::onLeaveSessionClicked);
    connect(refreshStatusButton, &QPushButton::clicked, this, &AdminWidget::onRefreshStatusClicked);
    connect(addUsersButton, &QPushButton::clicked, this, &AdminWidget::onAddUsersClicked);
    connect(deleteUsersButton, &QPushButton::clicked, this, &AdminWidget::onDeleteUsersClicked);
    connect(editUsersButton, &QPushButton::clicked, this, &AdminWidget::onEditUsersClicked);
}

void AdminWidget::setupLayout()
{
    // --- Session Group ---
    sessionGroupBox = new QGroupBox("Sessions", this);
    QVBoxLayout *sessionLayout = new QVBoxLayout;
    createSessionButton = new QPushButton("Create Session", this);
    deleteSessionButton = new QPushButton("Delete Session", this);
    sessionLayout->addWidget(createSessionButton);
    sessionLayout->addWidget(deleteSessionButton);
    sessionGroupBox->setLayout(sessionLayout);

    // --- User Group ---
    userGroupBox = new QGroupBox("Users", this);
    QVBoxLayout *userLayout = new QVBoxLayout;
    addUsersButton = new QPushButton("Add Users", this);
    deleteUsersButton = new QPushButton("Delete Users", this);
    editUsersButton = new QPushButton("Edit Users", this);
    userLayout->addWidget(addUsersButton);
    userLayout->addWidget(deleteUsersButton);
    userLayout->addWidget(editUsersButton);
    userGroupBox->setLayout(userLayout);

    // --- Status Group ---
    statusGroupBox = new QGroupBox("Status", this);
    QVBoxLayout *statusLayout = new QVBoxLayout;
    refreshStatusButton = new QPushButton("Refresh Status", this);
    statusLabel = new QLabel("Disconnected", this);
    statusLayout->addWidget(refreshStatusButton);
    statusLayout->addWidget(statusLabel);
    statusGroupBox->setLayout(statusLayout);

    // --- Session Join/Leave Layout ---
    sessionSelector = new QComboBox(this);
    joinSessionButton = new QPushButton("Join Session", this);
    leaveSessionButton = new QPushButton("Leave Session", this);
    QHBoxLayout *joinLeaveLayout = new QHBoxLayout;
    joinLeaveLayout->addWidget(sessionSelector);
    joinLeaveLayout->addWidget(joinSessionButton);
    joinLeaveLayout->addWidget(leaveSessionButton);

    // --- Main Layout ---
    QVBoxLayout *mainLayout = new QVBoxLayout(this);
    mainLayout->addWidget(sessionGroupBox);
    mainLayout->addLayout(joinLeaveLayout);
    mainLayout->addWidget(userGroupBox);
    mainLayout->addWidget(statusGroupBox);
    setLayout(mainLayout);
}

// --- Slots ---
void AdminWidget::onCreateSessionClicked() {
    QMessageBox::information(this, "Create", "Create Session clicked");
}
void AdminWidget::onDeleteSessionClicked() {
    QMessageBox::information(this, "Delete", "Delete Session clicked");
}
void AdminWidget::onJoinSessionClicked() {
    QMessageBox::information(this, "Join", "Join Session clicked");
}
void AdminWidget::onLeaveSessionClicked() {
    QMessageBox::information(this, "Leave", "Leave Session clicked");
}
void AdminWidget::onRefreshStatusClicked() {
    statusLabel->setText("Status: Refreshed");
}
void AdminWidget::onAddUsersClicked() {
    QMessageBox::information(this, "Add", "Add Users clicked");
}
void AdminWidget::onDeleteUsersClicked() {
    QMessageBox::information(this, "Delete", "Delete Users clicked");
}
void AdminWidget::onEditUsersClicked() {
    QMessageBox::information(this, "Edit", "Edit Users clicked");
}
