#include "startupwidget.h"
#include "adminwidget.h"
#include "regularuserwidget.h"
#include "database.h"
#include "logmanager.h"

#include <QVBoxLayout>
#include <QMessageBox>

StartupWidget::StartupWidget(QWidget* parent)
    : QWidget(parent)
{
    // ساخت وابستگی‌ها
    auto db = std::make_shared<Database>();
    auto logger = std::make_shared<logmanager>();
    auth = std::make_shared<AuthManager>(db, logger);

    // ساخت فرم ورود
    loginWidget = new LoginWidget(auth, this);
    connect(loginWidget, &LoginWidget::loginSuccessful, this, &StartupWidget::handleLogin);

    // چیدمان
    auto layout = new QVBoxLayout(this);
    layout->addWidget(loginWidget);
    setLayout(layout);
}

void StartupWidget::handleLogin(QString username, QString password)
{
    auto user = auth->getLoggedInUser(username, password);
    if (!user) {
        QMessageBox::warning(this, "خطا", "ورود ناموفق بود");
        return;
    }

    if (user->getRole() == Role::Admin) {
        auto admin = std::dynamic_pointer_cast<Admin>(user);
        auto adminWidget = new AdminWidget(admin);
        adminWidget->show();
    } else {
        auto regular = std::dynamic_pointer_cast<RegularUser>(user);
        auto regularWidget = new RegularUserWidget(regular);
        regularWidget->show();
    }

    this->close(); // بستن فرم ورود
}
