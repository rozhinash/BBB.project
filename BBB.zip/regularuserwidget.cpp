#include "regularuserwidget.h"
#include "ui_regularuserwidget.h"
#include <QMessageBox>

RegularUserWidget::RegularUserWidget(std::shared_ptr<RegularUser> user, QWidget *parent)
  : QFrame(parent), ui(new Ui::RegularUserWidget), currentUser(user)
{
    ui->setupUi(this);

    QString fullName = currentUser->getName() + " " + currentUser->getLastName();
    ui->WelcomeLabel->setText("خوش آمدی " + fullName);

    connect(ui->ViewHistoryButton, &QPushButton::clicked, this, &RegularUserWidget::onViewHistoryClicked);
    connect(ui->joinSessionButton , &QPushButton::clicked , this , &RegularUserWidget::onJoinSessionClicked);
    connect(ui->leaveSessionButton , &QPushButton::clicked , this , &RegularUserWidget::onLeaveSessionClicked);
}

RegularUserWidget::~RegularUserWidget()
{
    delete ui;
}

void RegularUserWidget::onViewHistoryClicked()
{
    QStringList history = currentUser->getSessionHistory();
    ui->SessionHistoryList->clear();
    ui->SessionHistoryList->addItems(history);
}
void RegularUserWidget::onJoinSessionClicked()
{
    QString sessionID = ui->sessionInput->text();
    if (sessionID.isEmpty()) {
        QMessageBox::warning(this, "هشدار", "کد جلسه را وارد کنید.");
        return;
    }

    currentUser->joinSession(sessionID);
    QMessageBox::information(this, "ورود", "شما به جلسه پیوستید.");
    onViewHistoryClicked(); // برای آپدیت لیست
}

void RegularUserWidget::onLeaveSessionClicked()
{
    QString sessionID = ui->sessionInput->text();
    if (sessionID.isEmpty()) {
        QMessageBox::warning(this, "هشدار", "کد جلسه را وارد کنید.");
        return;
    }

    currentUser->leaveSession(sessionID);
    QMessageBox::information(this, "خروج", "شما از جلسه خارج شدید.");
    onViewHistoryClicked(); // برای آپدیت لیست
}


