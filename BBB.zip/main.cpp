
#include "startupwidget.h"

#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    auto startup = new StartupWidget();
    startup->show();

    return a.exec();
}
