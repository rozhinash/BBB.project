#include "sessionwidget.h"
#include <QInputDialog>
#include <QMessageBox>
 #include "whiteboardwidget.h" // اگه ساختی

SessionWidget::SessionWidget(std::shared_ptr<User> currentUser, QWidget* parent)
    : QWidget(parent), user(currentUser)
{
    sessionList = new QListWidget(this);
    createBtn = new QPushButton("ایجاد جلسه", this);
    enterBtn = new QPushButton("ورود به جلسه", this);
    infoLabel = new QLabel("هیچ جلسه‌ای انتخاب نشده", this);

    auto layout = new QVBoxLayout(this);
    layout->addWidget(sessionList);
    layout->addWidget(infoLabel);
    layout->addWidget(createBtn);
    layout->addWidget(enterBtn);

    connect(createBtn, &QPushButton::clicked, this, &SessionWidget::handleCreateSession);
    connect(enterBtn, &QPushButton::clicked, this, &SessionWidget::handleEnterSession);

    loadSessions();
}

void SessionWidget::loadSessions()
{
    // اگر دیتابیس فعال نیست، جلسات ساختگی تستی
    QStringList fakeSessions = {"جلسه طراحی", "جلسه توسعه", "جلسه بررسی"};
    for (const auto& s : fakeSessions)
        sessionList->addItem(s);
}

void SessionWidget::handleCreateSession()
{
    QString title = QInputDialog::getText(this, "موضوع جلسه", "عنوان:");
    if (!title.isEmpty()) {
        sessionList->addItem(title);
        infoLabel->setText("جلسه جدید: " + title);
        // می‌تونی به LogManager ثبت‌ش هم اضافه کنی
    }
}

void SessionWidget::handleEnterSession()
{
    auto item = sessionList->currentItem();
    if (!item) {
        QMessageBox::warning(this, "توجه", "هیچ جلسه‌ای انتخاب نشده.");
        return;
    }

    QString sessionTitle = item->text();
    infoLabel->setText("ورود به جلسه: " + sessionTitle);

    // اگر فرم وایت‌برد ساختی، اینجا بازش کن
    // auto board = new WhiteboardWidget(sessionTitle, user);
    // board->show();
}
