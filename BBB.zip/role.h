#ifndef ROLE_H
#define ROLE_H

//#include "admin.h"
enum class Role{
    User,Admin, SuperAdmin , Regular
};

#endif// ROLE_H
