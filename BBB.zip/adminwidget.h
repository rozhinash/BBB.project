#ifndef ADMINWIDGET_H
#define ADMINWIDGET_H

#include <QWidget>
#include <QPushButton>
#include <QComboBox>
#include <QLabel>
#include <QGroupBox>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QFormLayout>

#include "admin.h"
#include "session.h"

class AdminWidget : public QWidget
{
    Q_OBJECT

public:
    explicit AdminWidget(std::shared_ptr<Admin> admin , QWidget*parent = nullptr);

private:
    QPushButton *createSessionButton;
    QPushButton *deleteSessionButton;
    QPushButton *joinSessionButton;
    QPushButton *leaveSessionButton;
    QPushButton *refreshStatusButton;
    QPushButton *addUsersButton;
    QPushButton *deleteUsersButton;
    QPushButton *editUsersButton;

    QComboBox *sessionSelector;
    QLabel *statusLabel;

    QGroupBox *sessionGroupBox;
    QGroupBox *userGroupBox;
    QGroupBox *statusGroupBox;

    void setupLayout();

private slots:
    void onCreateSessionClicked();
    void onDeleteSessionClicked();
    void onJoinSessionClicked();
    void onLeaveSessionClicked();
    void onRefreshStatusClicked();
    void onAddUsersClicked();
    void onDeleteUsersClicked();
    void onEditUsersClicked();
};

#endif // ADMINWIDGET_H
