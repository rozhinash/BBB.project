#ifndef SESSION_H
#define SESSION_H

#include <QString>
#include <QList>  //برای نگهدلری اعضا توی یه لیست
#include"../User/user.h"

class Session
{
public:
    Session(QString sessionId);
    ~Session();
    QString getSessionId() const;
    bool isActive() const;
    void endSession();
   //قابلیت عضویت در جلسه
    bool addParticipant(User* user);  //اضافه کردن یورذ جدید به جلسه
    bool removeParticipant(User* user); //حذف کاربر از جلسه
    QList<User*> getParticipant() const;  //گرفتن لیست اعضا
private:
    QString sessionId;
    bool active;
    QList<User*> Participants;   //لیست ادمای جلسه
};

#endif // SESSION_H
