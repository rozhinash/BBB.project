#include "role.h"
#include <QString>
QString roleToString(Role role) {
    switch (role) {
    case Role::User: return "User";
    case Role::Admin: return "Admin";
    case Role::SuperAdmin: return "SuperAdmin";
    case Role::Regular: return "Regular";
    default: return "Unknown";
    }
}

Role stringToRole(const QString& str) {
    QString val = str.toLower().trimmed();

    if (val == "user") return Role::User;
    if (val == "admin") return Role::Admin;
    if (val == "superadmin") return Role::SuperAdmin;
    if (val == "regular") return Role::Regular;

    return Role::User; // default fallback
}
