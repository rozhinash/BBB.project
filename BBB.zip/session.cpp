#include "session.h"

Session::Session(QString sessionId) : sessionId(sessionId), active(true) {}
Session::~Session(){}

QString Session::getSessionId() const {
    return sessionId;
}

bool Session::isActive() const {
    return active;
}

void Session::endSession() {
    active = false;
}
//اضافه کردن کاربر به جلسه
bool Session::addParticipant(User* user){
    if (user && !Participants.contains(user)){
        Participants.append(user);
    return true;
}
    return false;
}

//حذف عضو از جلسه
bool Session::removeParticipant(User* user){
    if (user && Participants.contains(user)){
        Participants.removeOne(user);
        return true;
    }
    return false;
    }
//لیست اعضا
 QList<User*> Session::getParticipant() const{
        return Participants;
    }
