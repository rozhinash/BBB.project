#ifndef LOGMANAGER_H
#define LOGMANAGER_H

#include <QMainWindow>
#include <QString>
#include <QFile>
#include <QTextStream>
#include <QDateTime>

class logmanager {
public:
    logmanager(const QString logFilePath = "app.log");
    ~logmanager();

    void logInfo(const QString& massage);
    void logWarning (const QString& message);
    void logError(const QString& message);
    void writeLog(const QString& level , const QString& message);

private:
    QFile m_logFile;

};

#endif // LOGMANAGER_H
